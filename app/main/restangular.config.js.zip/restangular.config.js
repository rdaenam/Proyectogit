angular
    .module('main')
    .config(RestangularConfig);

function RestangularConfig(RestangularProvider){
    RestangularProvider.setBaseUrl('https://jsonplaceholder.typicode.com');
}